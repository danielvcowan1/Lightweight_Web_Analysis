///////////////////////////////////////////////////////////////////////////////
// app.js
//
// Copyright (c) 2014 General Dynamics Inc.
// All rights reserved.
///////////////////////////////////////////////////////////////////////////////
requirejs.config({
  baseUrl: "js",
  paths: {
    "d3": "d3/d3",
    "d3.layout.cloud": "d3/d3.layout.cloud"
  },
  shim: {
    "jquery-ui": {
      exports: "$",
      deps: ['jquery']
    },
    "d3": {
      exports: "d3",
      init: function() {
        return {
          d3: d3
        }
      }
    },
    "d3.layout.cloud": {
      exports: "d3",
      deps: ["d3"]
    }
  }
});

requirejs(['scripts/setup', 'scripts/tanaFree']);