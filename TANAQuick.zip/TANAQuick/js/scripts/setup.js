///////////////////////////////////////////////////////////////////////////////
// setup.js
//
// Copyright (c) 2014 General Dynamics Inc.
// All rights reserved.
///////////////////////////////////////////////////////////////////////////////
define(function(require)
{
  var $ = require("jquery"),
  jqueryui = require("jquery-ui");
  /**
   * Sets up all jquery-ui widgets
  */
  var setupPage = function()
  {
    //Setup page
    $("#workingDialog").dialog({dialogClass: "no-close", autoOpen: false, modal: true, closeOnEscape: false, 
        draggable: false, resizable: false});
    $("#help").load("help.html");
    $("#contact").load("contact.html");
    $("#myTextData").tooltip({show: {delay: 20}, track:true});
    $("#mySubList").tooltip({show: {delay: 20}, track:true});
    $("#myJoinList").tooltip({show: {delay: 20}, track:true});
    $("#myDeleteList").tooltip({show: {delay: 20}, track:true});
    $("#inputTab").tooltip({show: {delay: 20}, track:true});
    $("#listsTab").tooltip({show: {delay: 20}, track:true});
    $("#corefTab").tooltip({show: {delay: 20}, track:true});
    $("#corefVisualTab").tooltip({show: {delay: 20}, track:true});
    $("#conceptsTab").tooltip({show: {delay: 20}, track:true});
    $("#degreeCentrality").tooltip({show: {delay: 20}, track:true});
    $("#wordCloudTab").tooltip({show: {delay: 20}, track:true});
    $("#textTab").tooltip({show: {delay: 20}, track:true});
    
    $("#accordion").accordion({ active: 0, collapsible : true, heightStyle: "content", beforeActivate: function(event, ui) 
      {
        if (ui.newHeader.hasClass("disabled"))
        {
          event.preventDefault();
        }
        return;
      }});
    $(".initDisabledHeader").addClass("disabled");
  }();
});