define(function()
{
  var format = function(text)
  {
    var listdata = "<table>";
    for (i=0;i<text.length;i++)
    {
      listdata = listdata+"<tr><td>"+text[i][0]+"</td><td>"+text[i][1]+"</td></tr>";
    }
    listdata = listdata+"</table>";
    return listdata;
  }
  
  var conceptlist = function(textdata)
  {
    var count = 1;
    var old = "";
    var sorted = [];
    
    //Make a copy of the text data and sort alphabetically
    wordlist = textdata.slice();
    wordlist.sort(function(a, b) {
      return a.text.localeCompare(b.text);
    });
    
    for (var i = 0; i < wordlist.length; i++)
    {
      if (wordlist[i].text.length > 0 && !wordlist[i].ignore) 
      {
        if (wordlist[i].text != old) 
        {
          if (old != "") 
          {
            sorted.push({count: count.toString(), concept: old});	      
          }
          count = 1;
        }
        else 
        {
          count = count + 1;
        }
        old = wordlist[i].text;
      }
    }
    sorted.sort(function(a, b)
    {
      return b.count - a.count;
    });
    return sorted;
  }
  
  
  return {conceptlist: conceptlist, format: format};
});