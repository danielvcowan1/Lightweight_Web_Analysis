///////////////////////////////////////////////////////////////////////////////
// tanaFree.js
//
// Copyright (c) 2014 General Dynamics Inc.
// All rights reserved.
///////////////////////////////////////////////////////////////////////////////
define(function(require) 
{
  var tanaReplace = require("./replace"),
      tanaLists = require("./datalists"),
      conceptsList = require("./conceptlist"),
      corefs = require("./corefpairs"),
      degreeCentrality = require("./degreeCentrality"),
      command = require("./commands"),
      classes = require("./classes"),
      util = require("./util"),
      visuals = require("./visuals"),
      $ = require("jquery"),
      jqueryui = require("jquery-ui");
  
  var buttons = function()
  {
    $("#GoButton")
      .button({disabled: false})
      .click(function(event) 
      {
        event.preventDefault();
        run(); 
      });

    $("#visualsButton")
      .button()
      .click(function(event)
      {
        event.preventDefault();
        visuals.displayVisual(concepts, coreferences);
      });
    $("#corefDataButton")
      .button()
      .click(function(event)
      {
        event.preventDefault();
        showCorefData();
      });
    $("#conceptDataButton")
      .button()
      .click(function(event)
      {
        event.preventDefault();
        showConceptData();
      });
    $("#degreeDataButton")
      .button()
      .click(function(event)
      {
        event.preventDefault();
        showDegreeData();
      });
    $("#sample")
      .button({disabled: false})
      .click(function(event)
      {
        event.preventDefault();
        loadGettysburg();
      })
  }();
  
  /**
   * Shows busy message to user and starts the summary process
   * Main entry point for program
  */
  var run = function()
  {
    $("#workingDialog").dialog( "open" );
    loadDeleteWords();
  }
  /**
   * Fills text areas with sample data
   * @param data Sample text
  */
  var fillSample = function(data)
  {
    $("#myTextData").val(data);
    $("#myDeleteList").val("we\nthey");
    $("#mySubList").val("consecrated,consecrate\ndedicated,dedicate");
    $("#myJoinList").val("civil war\n");
    $("#subCheck").prop("checked", true);
    $("#delCheck").prop("checked", true);
    $("#lowercaseCheck").prop("checked", true);
  }
  
  /**
   * Loads the common noise words and continues with 
   * the run process
  */
  var loadDeleteWords = function()
  {
    // Get delete words
    $.ajax({
      url: "deletewords.txt",
      dataType: "text",
      success: function(data) { tryMe(data); }
    });
  }
  
  /**
   * Loads gettysburg text and fills sample with it
  */
  var loadGettysburg = function()
  {
    $.ajax({
      url: "gettysburg.txt",
      dataType: "text",
      success: function(data) { 
        fillSample(data);
      }
    });
  }
  /**
   * Calls all subroutines on the data contained in all text areas.
   * @param deleteWords a string of comma separated words to remove from text
  */
  var tryMe = function(deleteWords)
  {
    $(".unselected-concept").remove();
    $("#fragment-3 br").remove();
    
    d3.selectAll("#fragment-1 div").remove();
    d3.selectAll("#fragment-2 div").remove();
    
    var nodeList = [];
    
    
    var deletedata = util.strip(document.getElementById("myDeleteList").value);
    deletedata = deletedata.split("\n");
    deleteWords = deleteWords.split(", ");
    
    var subdata = util.strip(document.getElementById("mySubList").value);
    subdata = subdata.split("\n");
    for (var j = 0; j < subdata.length; j++)
    {
      subdata[j] = subdata[j].split(",");
    }
    
    var joindata = util.strip(document.getElementById("myJoinList").value);
    var rawText = util.strip(document.getElementById("myTextData").value);
    
    
    
    var deleteCommon = document.getElementById("delCheck").checked;
    var subCommon = document.getElementById("subCheck").checked;
    var toLowerCase = document.getElementById("lowercaseCheck").checked;
    
    //PRE TOKEN WASHES
    displayLists(rawText);
    rawText = command.separateSymbols(rawText);
    
    var textData = [];
    var rawText = rawText.split(" ");
    
    //POST TOKEN WASHES
    
    
    //CONVERT TEXT TO CONCEPT OBJECTS
    for (var i = 0; i < rawText.length; i++)
    {
      textData[textData.length] = new classes.Concept(rawText[i], false, ["", ""], false);
    }
    
    
    if (toLowerCase)
    {
      nodeList[nodeList.length] = new classes.Node("Converting to Lowercase", command.lowercaseConcepts);
    }
    
    nodeList[nodeList.length] = new classes.Node("Ignore Symbols", command.ignoreSymbols);
    nodeList[nodeList.length] = new classes.Node("Joining custom Phrases", command.joinPhrases, joindata);
    nodeList[nodeList.length] = new classes.Node("Deleting Custom Words", command.deleteConcepts, deleteWords);
    
    if (deleteCommon)
    {
      nodeList[nodeList.length] = new classes.Node("Deleting Noise", command.deleteConcepts, deletedata);
    }
    nodeList[nodeList.length] = new classes.Node("Substituting Custom Words", command.substituteConcepts, subdata);
    
    if (subCommon)
    {
    nodeList[nodeList.length] = new classes.Node("Substituting British Words", 
                                                command.substituteConcepts, tanaReplace.replacebritish);
    nodeList[nodeList.length] = new classes.Node("Substituting Typos", 
                                                command.substituteConcepts, tanaReplace.misspellings);
    }
    
    for (var i = 0; i < nodeList.length; i++)
    {
      d3.select("#workingDialog").text(nodeList[i].name);
      nodeList[i].fun(textData, nodeList[i].data);
      
    }
    
    d3.select("#workingDialog").text("Generating Concept List");
    concepts = conceptsList.conceptlist(textData);

    visuals.displayBarChart(concepts, "#conceptBarChart");
    
    d3.select("#workingDialog").text("Creating Word Cloud");
    var cloudSize = visuals.getViewWidth();
    
    
    
    visuals.displayWordCloud(concepts.map(function(d) {
      return {text: d.concept, size: (d.count/concepts[0].count)*(cloudSize/10)};
    }), "#wordCloud");
    
    d3.select("#workingDialog").text("Generating Coreference Pairs");
    coreferences = corefs.conceptpairs(textData);
    
    var corefBarFormat = [];
    coreferences.map(function(d) 
    {
      corefBarFormat.push({count: +d.count, concept: d.from + " - " + d.to});

    });
    
    visuals.displayBarChart(corefBarFormat, "#corefBarChart");
    
    d3.select("#workingDialog").text("Calculating Degree Centrality");
    degrees = degreeCentrality.countLinks(coreferences);
    var degreeBarFormat = [];
    degrees.map(function(d)
    {
      degreeBarFormat.push({count: d[0], concept: d[1]});
    });
    visuals.displayBarChart(degreeBarFormat, "#degreeCentralityChart");
    
    d3.select("#workingDialog").text("Rendering Conditioned Html");
    render(textData);

    analysisRun = true;
    $("#workingDialog").dialog( "close" );
    $(".disabled").removeClass("disabled");
    $("#accordion").accordion("option", "active", 1);
  }
  

  
  /**
   * Function triggered when a concept is moused over. Highlights all instances
   * of concept with blue. Highlights all instances of coreferences with peach.
  */
  var highlightReferences = function(event)
  {
    var allSpans = $(".selected, .unselected-concept, .coref");
    for (var i = 0; i < allSpans.length; i++)
    {
      if (event.data.concept == allSpans[i].innerHTML)
      {
        allSpans[i].setAttribute("class", "selected");
      }
    }
    for (var i = 0; i < coreferences.length; i++)
    {
      if (coreferences[i].from == event.data.concept)
      {
        for (var j = 0; j < allSpans.length; j++)
        {
          if (allSpans[j].innerHTML == coreferences[i].to)
          {
            allSpans[j].setAttribute("class", "coref");
          }
        }
      }
      else if (coreferences[i].to == event.data.concept)
      {
        for (var j = 0; j < allSpans.length; j++)
        {
          if (allSpans[j].innerHTML == coreferences[i].from)
          {
            allSpans[j].setAttribute("class", "coref");
          }
        }
      }
    }
  }
  
  /**
   * Removes all highlighting from concepts.
  */
  var unhighlight = function()
  {
    var allTags = $(".coref, .selected");
    for (var i = 0; i < allTags.length; i++)
    {
      allTags[i].setAttribute("class", "unselected-concept");
    }
  }
 
  var showConceptData = function()
  {
    var newWindow = window.open();
    newWindow.document.write(conceptsList.format(concepts));
  }
  var showCorefData = function()
  {
    var newWindow = window.open();
    newWindow.document.write(corefs.printCoreferences());
  }
  var showDegreeData = function()
  {
    var newWindow = window.open();
    newWindow.document.write(degreeCentrality.printCentrality(degrees));
  }
 

  var displayLists = function(text)
  {
      var str = tanaLists.listAll(text);
      document.getElementById("fragment-4").innerHTML = str;
  }
  
  var render = function(textData)
  {
    
    var output = $("<div>");
    for (var i = 0; i < textData.length; i++)
    {
      if (textData[i].text == "\n")
      {
        $("<br/>").appendTo(output);
      }
      else if (textData[i].text != "")
      {
        var el;
        if (textData[i].tagged)
        {
          el = $(textData[i].tag[0] + textData[i].text + textData[i].tag[1]);
        }
        else
        {
          el = $("<span>" + textData[i].text + "</span>");
        }
        if (!textData[i].ignore)
        {
          el.on("mouseover", {concept: textData[i].text}, highlightReferences)
          .on("mouseout", function() { unhighlight() });
        }
       el.appendTo(output);
       el.addClass("unselected-concept");
       output.append(document.createTextNode(" "));
      }
    }
    $("#fragment-3").append(output);
  }
  

  

  
  var concepts = [];
  var coreferences = [];
  var degrees = [];
  var conditionedText;
  var analysisRun = false;
  
  return {run: run, highlightReferences: highlightReferences, unhighlight:unhighlight};
 });