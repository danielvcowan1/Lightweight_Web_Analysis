///////////////////////////////////////////////////////////////////////////////
// degreeCentrality.js
//
// Copyright (c) 2014 General Dynamics Inc.
// All rights reserved.
///////////////////////////////////////////////////////////////////////////////
define(function()
{
  var countLinks = function(coreferences)
  {
    var concepts = {};
    
    for (var i = 0; i < coreferences.length; i++)
    {
      var concept = coreferences[i].from;
      if (!concepts[concept])
      {
        concepts[concept] = 1;
      }
      else
      {
        concepts[concept]++;
      }
      
      concept = coreferences[i].to;
      if (!concepts[concept])
      {
        concepts[concept] = 1;
      }
      else
      {
        concepts[concept]++;
      }
    }
    
    //Convert to array
    var concArray = [];
    for (var prop in concepts)
    {
      if (concepts.hasOwnProperty(prop))
      {
        concArray.push([
          concepts[prop],
          prop
        ]);
      }
    }
    
    Array.sort(concArray, function(a, b)
    {
      return b[0] - a[0];
    });
    
    return concArray;
  };
  
  var printCentrality = function(concepts)
  {
    var output = "<table>";
    for (var i = 0; i < concepts.length; i++)
    {
      output += "<tr><td>" + concepts[i][1] + "</td><td>" + concepts[i][0] + "</td></tr>";
    }
    output += "</table>";
    return output;
  }
  
  
  return {printCentrality: printCentrality, countLinks : countLinks}; 
});