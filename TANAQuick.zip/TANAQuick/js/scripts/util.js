///////////////////////////////////////////////////////////////////////////////
// util.js
//
// Copyright (c) 2014 General Dynamics Inc.
// All rights reserved.
///////////////////////////////////////////////////////////////////////////////
  define(function()
  {
  /**
   * Sanitizes regular expressions so that they function as expected. 
   * (ie malicious users)
  */
  var escapeRegExp = function(string) {
    return string.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
  }
  /**
   * Replaces all instances of 'find' with 'replace' in 'string'
  */
  var replaceAll = function(string, find, replace) {
    return string.replace(new RegExp(escapeRegExp(find), 'g'), replace);
  }
  /**
   *  Naive html sanitization. This needs improved
   * TODO: Make sure this will work without any possibility
   * TODO: of injection.
  */
  var strip = function(html)
  {
    var tmp = document.createElement("DIV");
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || "";
  }
  return {escapeRegExp: escapeRegExp, replaceAll: replaceAll, strip: strip};
  });