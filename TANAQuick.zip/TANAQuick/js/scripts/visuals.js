define(function(require)
{
  var d3 = require("d3"),
      d3Cloud = require("d3.layout.cloud");
  
  
  
  
  var displayBarChart = function(data, id)
  {
    d3.selectAll(id + " g")
      .remove();
  
    var width = getViewWidth();
    var barHeight = 20;
    
    var max = 0; 
    for (var i = 0; i < data.length; i++)
    {
      if (data[i].count > max)
      { 
        max = data[i].count;
      }
    }
    
    var x = d3.scale.linear()
      .domain([0, max])
      .range([0, width - 125]);
    
    var chart = d3.select(id)
      .attr("width", width)
      .attr("height", barHeight * data.length);
      
    var bar = chart.selectAll("g")
      .data(data)
     .enter().append("g")
      .attr("transform", function(d, i) { return "translate(" + 125 + "," + i * barHeight + ")"; });
      
    bar.append("rect")
      .attr("width", function(d) { return x(d.count);})
      .attr("height", barHeight - 1);
      
    bar.append("text")
      .style("text-anchor", "start")
      .attr("y", barHeight / 2)
      .attr("x", - 120)
      .attr("dy", ".35em")
      .text(function(d) { return d.concept + " - " + d.count; });
  }
  
  
    // ***** DISPLAY COREF VISUAL
  var displayVisual = function(concepts, coreferences)
  {
    nodes = [];
    edges = [];
    
    for (var i = 0; i < coreferences.length; i++)
    {
      var datum = coreferences[i];
      var edge = {};
      for (var j = 0; j < concepts.length; j++)
      {
        var conc = concepts[j];
        if (conc.concept == datum.from)
        {
          edge.source = conc;
        }
        
        if (conc.concept == datum.to)
        {
          edge.target = conc;
        }
      }
      if( edge.target && edge.source)
      {
        edges.push(edge);
      }
    }
    
    var force = d3.layout.force()
      .size([getViewWidth(),getViewWidth()])
      .charge(-120)
      .linkDistance(30)
      .nodes(concepts)
      .links(edges)
      .start();
      
    var scale = 1;
      
    var zoom = d3.behavior.zoom()
      .scaleExtent([0.5, 10])
      .on("zoom", function()
      {
        scale = d3.event.scale;
        graphics.attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
        textNode.attr("font-size", 12/scale);
        node.attr("r", 8/scale);
        node.style("stroke-width", 1 / scale);
        link.style("stroke-width", 2 / scale);
      });
      
    var svg = d3.select("#canvas").append("svg")
      .attr("width", getViewWidth())
      .attr("height", getViewWidth())
        .append("g")
        .call(zoom);
        
    svg.append("g").append("rect")
      .attr("width", getViewWidth())
      .attr("height", getViewWidth())
      .style("stroke", "gray")
      .style("fill", "#EEE")
      .style("pointer-events", "all");
      
    var graphics = svg.append("g");
      
    var link = graphics.selectAll(".link")
      .data(edges)
      .enter().append("line")
        .attr("class", "link")
        .style("stroke", "#555555");
      
    var node = graphics.selectAll(".node")
      .data(concepts)
      .enter().append("circle")
      .call(force.drag);
      
    node
      .attr("r", 8)
      .style("fill", "orange")
      .style("stroke", "#EEEEEE")
      .attr("class", "node");
      
    var textNode = graphics.selectAll("text.node")
      .data(concepts).enter().append("text");
      
    textNode
      .text(function(d) { return d.concept; })
      .call(force.drag);
      
    
      
    force.on("tick",function() 
    {
      link.attr("x1", function(d) { return d.source.x; })
          .attr("y1", function(d) { return d.source.y; })
          .attr("x2", function(d) { return d.target.x; })
          .attr("y2", function(d) { return d.target.y; });
          
      node.attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; })
          .attr("r", 8 * (1/ scale));
      
      textNode.attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; })
              .attr("font-size", 12 * (1/scale));
    });
  }
  
    // DISPLAY WORD CLOUD
  var displayWordCloud = function(words, id)
  {
    if (d3)
    {
      wordCloudID = id;
      d3.select(wordCloudID + " g").remove();

      var cloudSize = getViewWidth();
      
      d3.layout.cloud().size([cloudSize, cloudSize])
        .words(words)
        .padding(5)
        .rotate(function() {return 0; })
        .font("Impact")
        .fontSize(function(d) { return d.size; })
        .on("end", draw)
        .start();
    }
    
  }
  /**
   * Helper function for drawWordCloud
  */
  var draw = function(words) 
  {
    var cloudSize = getViewWidth();
    var fill = d3.scale.category20();
    d3.select(wordCloudID)
    .append("g")
      .attr("transform", "translate("+ (cloudSize/2).toString() +", "+ (cloudSize/2).toString() +")")
    .selectAll("text")
      .data(words)
    .enter().append("text")
      .style("font-size", function(d) { return d.size + "px"; })
      .style("font-family", "Impact")
      .style("fill", function(d, i) { return fill(i); })
      .attr("text-anchor", "middle")
      .attr("transform", function(d) {
        return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
      })
      .text(function(d) { return d.text; });
  }
    /**
   * If window is smaller than 800px, Set a wordcloud width at 80%
   * of window width. Otherwise use 750px.
  */
  var getViewWidth = function()
  {
    var size = 700;
    var windowWidth = $("window").width();
    if (!windowWidth) windowWidth = window.innerWidth;
    if (windowWidth && windowWidth > 800)
    {
      size = 700;
    }
    else if (windowWidth < 800)
    {
      size = windowWidth * 0.7;
    }
    return size;
  } 
  
  var wordCloudID = "";
  
  return {displayBarChart: displayBarChart, displayVisual: displayVisual, displayWordCloud: displayWordCloud, getViewWidth: getViewWidth};
});