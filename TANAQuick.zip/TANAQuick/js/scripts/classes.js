define(function()
{
  var Concept = function(text, tagged, tag, ignore)
  {
    this.text = text;
    this.tagged = tagged;
    this.tag = tag;
    this.ignore = ignore;
  }
  
  var Node = function(name, fun, data)
  {
    this.name = name;
    this.fun = fun;
    this.data = data;
  }
  
  return {Concept: Concept, Node: Node}
});