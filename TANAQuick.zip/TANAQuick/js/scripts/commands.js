define(function(require)
{
  var classes = require("./classes"),
      util = require("./util");
  /*
   * PUBLIC FUNCTIONS
  */
  var deleteConcepts = function(textData, deleteWords)
  {
    applyToEachToken(textData, deleteToken, deleteWords, ["<del>", "</del>"]);
  }
  
  var substituteConcepts = function(textData, substituteWords)
  {
    applyToEachToken(textData, substituteToken, substituteWords, ["<i>", "</i>"]);
  }
  
   /**
   * Looks through data for a phrase to join with underscores
   * @param joindata String containing phrases separated by newlines
   * @param textData String to search through for phrases
   * @return modified String
  */
  var joinPhrases = function(textData, joindata)
  {
    var joindata = joindata.split("\n");
    var word = [];
    for (var i = 0; i < joindata.length; i++)
    {
      word[i] = joindata[i];
      joindata[i] = joindata[i].split(" ");
    }
    for (var i = 0; i < textData.length; i++)
    {
      for (var j = 0; j < joindata.length; j++)
      {
        var found = true;
        for (var k = 0; k < joindata[j].length; k++)
        {
          if (i + k >= textData.length || joindata[j][k] != textData[i + k].text)
          {
            found = false;
            break;
          }
        }
        if (found)
        {
          textData.splice(i, 0, new classes.Concept(word[j], true, ["<u>","</u>"], false));
          textData.splice(i+1, joindata[j].length);
        }
      }
    }
    return textData;
  }
  
  
  var lowercaseConcepts = function(textData)
  {
    for (var i = 0; i < textData.length; i++)
    {
      textData[i].text = textData[i].text.toLowerCase();
    }
    return textData;
  }
  
    /**
   * adds space between symbols and words so the tokenizer will not confuse them
   * @param text String to separate symbols from
   * @return text String but with spaces added between tokens.
  */
  var separateSymbols = function(text)
  {
    text = util.replaceAll(text, ".", " . ");
    text = util.replaceAll(text, ",", " , ");
    text = util.replaceAll(text, "—", " — ");
    text = util.replaceAll(text, "-", " - ");
    text = util.replaceAll(text, "\n", " \n ");
    text = util.replaceAll(text, ":", " : ");
    text = util.replaceAll(text, ";", " ; ");
    text = util.replaceAll(text, "!", " ! ");
    text = util.replaceAll(text, "?", " ? ");
    text = util.replaceAll(text, "(", " ( ");
    text = util.replaceAll(text, ")", " ) ");
    text = util.replaceAll(text, "\"", " \" ");
    return text;
  }
  
  /**
   * Removes symbols from text
   * @param text String to remove symbols from
   * @return String with no symbols
  */
  var ignoreSymbols = function(text)
  {
    for (var i = 0; i < text.length; i++)
    {
      if (text[i].text == ",")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == ".")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == "-")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == "\n")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == ":")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == ";")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == "?")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == "!")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == "(")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == ")")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == "{")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == "}")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
      else if (text[i].text == "\"")
      {
        text[i].ignore = true;
        text[i].skip = true;
      }
    }
    return text;
  }
  
  /*
   * PRIVATE FUNCTIONS
  */
  
  var applyToEachToken = function(textData, fun, extraData)
  {
    for (var i = 0; i < textData.length; i++)
    {
      var token = textData[i].text;
      var changeFlag = false;
      
      if (!textData[i].tagged)
      {
        fun(textData[i], extraData);
      }
    }
  }
  
    var deleteToken = function(textData, deletedata) 
  {
    var token = textData.text;
    for (var j = 0; j < deletedata.length; j++)
    {
      if (token.toLowerCase() == deletedata[j].toLowerCase())
      {
        deleteFlag = true;
        textData.tagged = true;
        textData.tag = ["<del>", "</del>"];
        textData.ignore = true;
        break;
      }
    }
  }
    /**
   * Takes a word and looks for a possible substitution
   * @param token the word to search for
   * @param subdata an Array of substitution values. [0] is search term
   *                  [1] is replace term
   * @param subCommon If true, substitute common words
   * @return First value is true if token was substituted. 
   *          second value is the (possibly changed) word
  */
  var substituteToken = function(textData, subdata)
  {
    var token = textData.text;
    
    for (var j = 0; j < subdata.length; j++)
    {
      if (subdata[j].length == 2)
      {
        subdata[j][0].trim();
        subdata[j][1].trim();
        if (token === subdata[j][0])
        {
          subFlag = true;
          textData.text = subdata[j][1];
          textData.tag = ["<i>", "</i>"];
          textData.tagged = true;
          break;
        }
      }
    }
  }

  return {deleteConcepts: deleteConcepts, substituteConcepts: substituteConcepts, lowercaseConcepts: lowercaseConcepts,
    joinPhrases: joinPhrases, separateSymbols: separateSymbols, ignoreSymbols: ignoreSymbols }
  
});