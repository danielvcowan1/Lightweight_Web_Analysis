define(function()
{
  var conceptpairs = function(textdata)
  {
    var windowSize = 5;
    var concp = [];
    
    var wordlist = textdata.slice(0);

    //Find the next windowSize words after the current word, and create a link between them
    for (var i = 0; i < wordlist.length - 1; i++){
      var skipped = 0;
      if (wordlist[i].text.length > 0 && !wordlist[i].ignore && wordlist[i] != "\n"){
        for (var end = 1; end <= windowSize + skipped; end++){
          if (i + end >= wordlist.length - 1)
          {
            continue;
          }
          
          else if (wordlist[i + end].skip || wordlist[i + end] == "\n")
          {
            skipped++;
          }
          
          else if (wordlist[i + end].text.length > 0 && !wordlist[i + end].ignore && wordlist[i + end] != "\n")
          {
            var link = {from: wordlist[i].text, to: wordlist[i + end].text};
            concp.push(link);
          }
        }
      }	
    }
    
    //Make all duplicates have the same direction.
    for (var i = 0; i < concp.length; i++)
    {
      for (var j = 0; j < concp.length; j++)
      {
        if (j == i)
        {
          break;
        }
        
        if (concp[i].from == concp[j].to && concp[i].to == concp[j].from)
        {
          var tmp = concp[j].from;
          concp[j].from = concp[j].to;
          concp[j].to = tmp;
        }
      }
    }
    
    //Sort by from concept, then by to concept
    concp = concp.sort(function(a, b)
    {
      var val = a.from.localeCompare(b.from);
      if (val == 0)
      {
        return a.to.localeCompare(b.to);
      }
      return val;
    });
    
    
    var count = 1;
    var old = {from: "", to: ""};
    var sorted = [];

    //Compound duplicates to one instance with a count variable
    for (var i = 0; i < concp.length; i++) {
      //If old isn't the same as current add to list and restart count
      if (!(concp[i].from == old.from && concp[i].to == old.to)) {
        if (old.from.length > 0 && old.to.length > 0) {
          sorted.push({count: count.toString(), from: old.from, to: old.to});	  
        }
        count = 1;
      }
      else {
        count++;
      }
      old = concp[i];
    }

    //sort by occurrence
    sorted.sort(function(a,b)
    {
      return b.count - a.count;
    });
    coreferences = sorted;
    return sorted;
  }
  /**
   * Creates an html table of coreferences and weights
   */
  var printCoreferences = function()
  {
    var out = "<table>";
    for (var i = 0; i < coreferences.length; i++)
    {
      out += "<tr><td>" + coreferences[i].count + "</td><td>" + 
        coreferences[i].from + "</td><td>" + coreferences[i].to +"</td></tr>";
    }
    out += "</table>";
    
    return out;
  }
  
  coreferences = [];
  
  return {conceptpairs: conceptpairs, printCoreferences: printCoreferences};
});
