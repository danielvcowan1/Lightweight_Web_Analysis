///////////////////////////////////////////////////////////////////////////////
// datalists.js
//
// Copyright (c) 2014 General Dynamics Inc.
// All rights reserved.
///////////////////////////////////////////////////////////////////////////////
define(function()
{
  var listcurrency = function(textdata)
  {
    var founddata;
    var output = "<h3>Currency : </h3>";
    founddata = textdata.match(/\$\d+(,\d\d\d)*(.\d\d)?/g);
    if (founddata == null) {
      return output + "<p>None found</p>";
    }
    
    for (var i = 0; i < founddata.length; i++){
      output += founddata[i] + "<br>\n";
    }
    return output;
  }

  var listtime = function(textdata)
  {
    var founddata;
    var output = "<h3>Times: </h3>";
    founddata = textdata.match(/([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?/g);
    if (founddata == null) {
      return output + "<p>None found</p>";
    }
    
    for (var i = 0; i < founddata.length; i++)
    {
      output += founddata[i] + "<br>";
    }
    return output;
  }

  var listdate = function(textdata)
  {
    var founddata;
    var output = "<h3>Dates: </h3>";
    founddata = textdata.match(/\b((1[0-2])|(0?[1-9]))\/((([1-2][0-9])|(0?[1-9]))|(3[01]))\/([0-9]+)/g);
    if (founddata == null) {
      return output + "<p>None found</p>";
    }
    
    for (var i = 0; i < founddata.length; i++){
      
      output += founddata[i] + "<br>";
    }
    return output;
  }


  var listip = function(textdata)
  {
    var founddata;
    var output = "<h3>IP Addresses: </h3>";
    founddata = textdata.match(/\b(((1[0-9])?[0-9]|[1-9][0-9]|2[0-4][0-9]|25[0-5])\.){3}((1[0-9])?[0-9]|[1-9][0-9]|2[0-4][0-9]|25[0-5])\b/g);
    if (founddata == null) {
      return output + "<p>None found</p>";
    }
    
    for (var i = 0; i < founddata.length; i++){
      output += founddata[i] + "<br>";
    }
    return output;
  }

  var listemail = function(textdata)
  {
    var founddata;
    var output = "<h3>Emails: </h3>";
    founddata = textdata.match(/[A-Za-z0-9._%+-]+@([A-Za-z0-9-]+\.)+[A-Za-z]{2,4}/g);
    if (founddata == null) {
      return output + "<p>None found</p>";
    }
    
    for (var i = 0; i < founddata.length; i++){
      output += founddata[i] + "<br>";
    }
    return output;
  }

  var listurl = function(textdata)
  {
    var founddata;
    var output = "<h3>URLs: </h3>";
    founddata = textdata.match(/((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/g);
    if (founddata == null) {
      return output + "<p>None found</p>";
    }
    
    for (var i = 0; i < founddata.length; i++){
      output += founddata[i] + "<br>";
    }
    return output;
  }

  var listphone = function(textdata)
  {
    var founddata;
    var output = "<h3>Phone Numbers: </h3>";
    founddata = textdata.match(/((\((\d{3})\))|(\d{3}))([\-\s]?)(\d{3})([\-\s]?)(\d{4})/g);
    if (founddata == null) {
      return output + "<p>None found</p>";
    }
    
    for (var i = 0; i < founddata.length; i++){
      output += founddata[i] + "<br>";
    }
    return output;
  }

  var listmention = function(textdata)
  {
    var founddata;
    var output = "<h3>Mentions: </h3>";
    founddata = textdata.match(/@([A-Za-z]\w*)/g);
    if (founddata == null) {
      return output + "<p>None found</p>";
    }
    
    for (var i = 0; i < founddata.length; i++){
      output += founddata[i] + "<br>";
    }
    return output;
  }

  var listhashtag = function(textdata)
  {
    var founddata;
    var output = "<h3>Hashtags: </h3>"
    founddata = textdata.match(/#[A-Za-z0-9_]*/g);
    if (founddata == null) {
      return output + "<p>None found</p>";
    }
    for (var i = 0; i < founddata.length; i++){
      output += founddata[i] + "<br>";
    }
    return output;
  }
  
  /**
   * Runs all regex expressions on data and returns some html to display it
  */
  var listAll = function(textdata)
  {
    var str = listhashtag(textdata);
    str += listmention(textdata);
    str += listphone(textdata);
    str += listurl(textdata);
    str += listemail(textdata);
    str += listip(textdata);
    str += listdate(textdata);
    str += listtime(textdata);
    str += listcurrency(textdata);
    return str;
  }
  
  return {listAll: listAll};
});


